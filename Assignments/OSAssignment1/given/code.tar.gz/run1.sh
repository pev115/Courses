./start 5
sleep 1
./producer 1 3 & 
./consumer 1 &
