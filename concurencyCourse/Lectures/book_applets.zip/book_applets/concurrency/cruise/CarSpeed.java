package concurrency.cruise;

public interface CarSpeed {

    public int getSpeed();

    public void setThrottle(double val);

}