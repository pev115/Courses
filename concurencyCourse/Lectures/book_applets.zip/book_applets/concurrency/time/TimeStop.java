package concurrency.time;

public class TimeStop extends Exception {

    public TimeStop(String s) {super(s);}
    public TimeStop() {super();}

}